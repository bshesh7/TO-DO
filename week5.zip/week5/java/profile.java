package com.example.bme_001;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class profile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        getSupportActionBar().setTitle("Profile");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //Bottom navigation start
        //initialise and assign variable
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        //Set home selected
        bottomNavigationView.setSelectedItemId(R.id.home);

        //Perform ItemSelectedListener
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()){
                    case R.id.home:
                        return true;
                    case R.id.fooditem:
                        startActivity(new Intent(getApplicationContext()
                                ,fooditem.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.compete:
                        startActivity(new Intent(getApplicationContext()
                                ,Compete.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.routine:
                        startActivity(new Intent(getApplicationContext()
                                ,routine.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.exercise:
                        startActivity(new Intent(getApplicationContext()
                                ,exercise.class));
                        overridePendingTransition(0,0);
                        return true;
                }
                return false;
            }
        });
        //Bottom navigation end

    }
}
