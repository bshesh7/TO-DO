var bodyparser = require('body-parser');
var data = [{item: 'get milk'}, {item: 'walk dog'}, {item: 'k'}];
var urlencodedParser = bodyparser.urlencoded({extended: false});
module.exports = function (app) {


    app.get('/todo',function (req,res){
        res.render('todo',{todo: data});
    });

    app.post('/todo',function (req,res){
        data.push(req.body);
        res.json(data);
    });

    app.delete('/todo',function (req,res){

    });


};