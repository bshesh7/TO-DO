package com.example.bme_001;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import org.json.JSONObject;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    String ip ="";
    TextView astrodataView2;
    //Menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.topappbar,menu);
        return super.onCreateOptionsMenu(menu);
    }
    // three dot menu top bar
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.settings:
                Log.i("Item Selected","Settings");
                return true;
            case R.id.help:
                Log.i("Item Selected","Help");
                return true;
            case R.id.level:
                Log.i("Item Selected","Level");
                Intent intent = new Intent(this, level.class);
                startActivity(intent);
                return true;
            case R.id.profile:
                Log.i("Item Selected","Profile");
                return true;



            default:
                return true;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Text views
        astrodataView2 = findViewById(R.id.astrodataView2);

        //for first time user startup messages
        SharedPreferences pref = getSharedPreferences("pref",MODE_PRIVATE);
        boolean firstStart = pref.getBoolean("firstStart",true);
        if(firstStart){
            showStartDialog();
        }

        //for API call
        DownloadTask task = new DownloadTask();
        task.execute("https://api.ipify.org?format=json");


        //Bottom navigation start
        //initialise and assign variable
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        //Set home selected
        bottomNavigationView.setSelectedItemId(R.id.home);

        //Perform ItemSelectedListener
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()){
                    case R.id.home:
                        return true;
                    case R.id.fooditem:
                        startActivity(new Intent(getApplicationContext()
                                ,fooditem.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.compete:
                        startActivity(new Intent(getApplicationContext()
                                ,Compete.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.routine:
                        startActivity(new Intent(getApplicationContext()
                                ,routine.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.exercise:
                        startActivity(new Intent(getApplicationContext()
                                ,exercise.class));
                        overridePendingTransition(0,0);
                        return true;
                }
                return false;
            }
        });
        //Bottom navigation end
    }

    // This is for showing the first time user start up messages
    private void showStartDialog() {
        Intent intent = new Intent(this, firstTimeUser.class);
        startActivity(intent);

        SharedPreferences pref = getSharedPreferences("pref",MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putBoolean("firstStart",false);
        editor.apply();
    }

    // API call
    public class DownloadTask extends AsyncTask<String,Void, String> {

        @Override
        protected String doInBackground(String... urls) {
            String result ="";
            URL url;
            HttpURLConnection urlConnection = null;

            try {
                url = new URL(urls[0]);
                urlConnection = (HttpURLConnection) url.openConnection();
                InputStream in = urlConnection.getInputStream();
                InputStreamReader reader = new InputStreamReader(in);
                int data = reader.read();

                while(data!=-1){
                    char current= (char) data;
                    result +=current;
                    data = reader.read();
                }
                return result;


            }catch (Exception e){
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            //Log.i("JSON",s);
            try {
                //Log.i("JSON",s);
                JSONObject jsonObject = new JSONObject(s);
                String ipInfo = jsonObject.getString("ip");
                Log.i("ip :: ",ipInfo);
                DownloadTask2 task2 = new DownloadTask2();
                task2.execute("https://api.ipgeolocation.io/astronomy?apiKey=876e2dc0a8624653a7d243e0cb8e1257&ip="+ipInfo+"&lang=cn");



            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

    public class DownloadTask2 extends AsyncTask<String,Void, String> {

        @Override
        protected String doInBackground(String... urls) {
            String result ="";
            URL url;
            HttpURLConnection urlConnection = null;

            try {
                url = new URL(urls[0]);
                urlConnection = (HttpURLConnection) url.openConnection();
                InputStream in = urlConnection.getInputStream();
                InputStreamReader reader = new InputStreamReader(in);
                int data = reader.read();

                while(data!=-1){
                    char current= (char) data;
                    result +=current;
                    data = reader.read();
                }
                return result;


            }catch (Exception e){
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            //Log.i("JSON",s);
            try {
                Log.i("JSON",s);
                String astroInfo = "";
                JSONObject jsonObject = new JSONObject(s);
                String sunriseInfo = jsonObject.getString("sunrise");
                String sunsetInfo = jsonObject.getString("sunset");
                String moon_altitude_string = jsonObject.getString("moon_altitude");

                //
                double moon_altitude = Double.parseDouble(moon_altitude_string);

                int scaling_factor = 0;
                double c = 0;
                double e = 0;
                double jd = 0;
                double b = 0;
                int day = 2;
                int year = 2020;
                int month = 6;
                if(month<3){
                    year--;
                    month+=12;
                }
                ++month;
                c = 365.25*year;
                e=30.6*month;
                jd= c+e+day- 694039.09;
                jd = jd/29.5305882;
                b = Math.floor(jd);
                jd = jd - b;
                b = Math.round(jd*8);

                if(b>=8){
                    b=0;
                }
                if(b == 0){
                    scaling_factor = 10;
                }else if(b == 1){
                    scaling_factor = 7;
                }else if(b == 2){
                    scaling_factor = 2;
                }else if(b ==3){
                    scaling_factor = 7;
                }else if(b == 4){
                    scaling_factor = 10;
                }else if(b==5){
                    scaling_factor = 7;
                }else if(b == 6){
                    scaling_factor = 2;
                }else if(b==7){
                    scaling_factor = 7;
                }
                double pi = 3.14;
                double radian_angle = (pi/180)*(90-moon_altitude);
                double tidal_potential = ((3*Math.cos(radian_angle)*Math.cos(radian_angle)) - 1)/2;
                double lunar_meter = tidal_potential*scaling_factor;
                String lunar_scale = "";

                if(lunar_meter> -5 && lunar_meter < -3.5){
                    lunar_scale = "Lunar meter : 1";
                }else if(lunar_meter > -3.5 && lunar_meter < -2){
                     lunar_scale = "Lunar meter : 2";
                }else if(lunar_meter > -2 && lunar_meter < -0.5){
                     lunar_scale = "Lunar meter : 3";
                }else if(lunar_meter > -0.5 && lunar_meter < 1){
                     lunar_scale = "Lunar meter : 4";
                }else if(lunar_meter > 1 && lunar_meter < 2.5){
                     lunar_scale = "Lunar meter : 5";
                }else if(lunar_meter> 2.5 && lunar_meter < 4){
                     lunar_scale = "Lunar meter : 6";
                }else if(lunar_meter> 4 && lunar_meter < 5.5){
                     lunar_scale = "Lunar meter : 7";
                }else if(lunar_meter> 5.5 && lunar_meter < 7){
                     lunar_scale = "Lunar meter : 8";
                }else if(lunar_meter> 7 && lunar_meter < 8.5){
                     lunar_scale = "Lunar meter : 9";
                }else if(lunar_meter> 8.5 && lunar_meter < 10){
                     lunar_scale = "Lunar meter : 10";
                }
                if(!sunriseInfo.equals("") && !sunsetInfo.equals("")){
                    astroInfo += "  Sunrise: " + sunriseInfo + "   Sunset: " + sunsetInfo + "  "+ lunar_scale;
                }

                if(!astroInfo.equals("")){
                    astrodataView2.setText(astroInfo);
                }
                //
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
