package com.example.bme_001;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

public class firstTimeUser extends AppCompatActivity {
    TextView textView5;
    Button later;
    Button enterinfo2;
    Button buttonready;
    MediaPlayer mediaPlayer;

    public void laterFunction(View view){
        mediaPlayer.stop();
        finish();
    }
    public void onReady(View view){
        buttonready.setVisibility(View.INVISIBLE);
        textView5.setVisibility(View.VISIBLE);
        later.setVisibility(View.VISIBLE);
        enterinfo2.setVisibility(View.VISIBLE);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_time_user);

        mediaPlayer = MediaPlayer.create(this,R.raw.backgroundmusic);
        mediaPlayer.start();
        mediaPlayer.setLooping(true);


         textView5 = (TextView) findViewById(R.id.finalmessage);
         later = (Button) findViewById(R.id.later2);
         enterinfo2 = (Button) findViewById(R.id.enterinfo2);


        final TextView textView1 = (TextView) findViewById(R.id.textView1);
        final TextView textView3 = (TextView) findViewById(R.id.textView3);
        final TextView textView4 = (TextView) findViewById(R.id.textView4);
        buttonready = (Button) findViewById(R.id.buttonready);
        buttonready.setVisibility(View.INVISIBLE);



        new CountDownTimer(2000,1000){
            @Override
            public void onTick(long millisUntilFinished) {

            }
            public void onFinish() {
//////////////////////
                textView1.animate().alpha(0).setDuration(3000);
                new CountDownTimer(2000, 1000) {
                    @Override
                    public void onTick(long millisUntilFinished) {

                    }

                    public void onFinish() {
                        textView3.animate().alpha(1).setDuration(2000);
                        new CountDownTimer(3000, 1000) {
                            @Override
                            public void onTick(long millisUntilFinished) {

                            }

                            public void onFinish() {
                                textView3.animate().alpha(0).setDuration(2000);
                                new CountDownTimer(3000, 1000) {
                                    @Override
                                    public void onTick(long millisUntilFinished) {

                                    }

                                    public void onFinish() {
                                        textView4.animate().alpha(1).setDuration(2000);
                                            new CountDownTimer(3000, 1000) {
                                            @Override
                                            public void onTick(long millisUntilFinished) {

                                            }
                                            public void onFinish() {
                                                textView4.animate().alpha(0).setDuration(2000);
                                                ////////
                                                    new CountDownTimer(3000, 1000) {
                                                        @Override
                                                        public void onTick(long millisUntilFinished) {

                                                        }

                                                        public void onFinish() {
                                                            //buttonready.animate().alpha(1).setDuration(2000);

                                                            buttonready.setVisibility(View.VISIBLE);


                                                        }
                                                    }.start();
                                                //////////
                                                }
                                        }.start();
                                    }
                                }.start();
                            }
                        }.start();
                    }
                }.start();
            }
///////////////////////////////////////

    }.start();

}


}
